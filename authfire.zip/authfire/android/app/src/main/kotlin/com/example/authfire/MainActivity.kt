package com.example.authfire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
